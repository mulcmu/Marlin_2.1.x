The iconpack "The Round Miracle" was made by Sergey Alexeyev (Acenotass). 'GIMP' and 'FastStone Image Viewer' graphic editors were used to create the icons.
Use only for firmware version above 26.x @ 2020/11/04
email: s.n.alexeyev@gmail.com
