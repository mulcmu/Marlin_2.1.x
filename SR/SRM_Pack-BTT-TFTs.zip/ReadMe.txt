------Supported Screens---------
Only the TFTs listed below are currently supported.
======BTT TFT STM32 chip========
BTT_TFT35_V1.0, V1.1, V1.2, V2.0, V3.0, E3_V3.0 and B1_V3.0
BTT_TFT50_V3.0
BTT_TFT70_V3.0
======BTT TFT GD32 chip=========
BTT_GD_TFT35_V2.0, V3.0, E3_V3.0 and B1_V3.0
BTT_GD_TFT50_V3.0
BTT_GD_TFT70_V3.0

--------Marlin Dependencies--------
Minimum Marlin firmware version: 2.1
Distribution date: 2022-08-04

--------Connecting the TFT to the Mainboard---------
Touch Mode Setup
In order to use the Touch Mode on your screen:
Connect the 5pin serial cable according to your mainboard (serial port)
Make sure the same BAUDRATE is defined on both the Marlin and 
TFT firmwares(Menu/Settings/Connection/S-port/1-Printer):
QQSP => 115000 BAUDS
SR   => 250000 BAUDS
Or connect the two ten-wire strands to the EXP1/EXP2 ports of the display
and your MoBo in addition to the serial cable.

---------Update & Themes -----------
Two themes avaible modified by me:
- Unified Menu Theme
- The Round Miracle Theme by Acenotass

To use them, copy to SD Card root directory:
- the appropriate firmware (BIGTREE_XXXXXXX.bin), 
- the configs (config.ini, language_en.ini)
- Retrieve in the theme directory,
the screen template folder which contains the icons and fonts without changing the name.

Example for a QQSP with a TFT35v3 screen in portrait mode and with the theme "The Round Miracle":
- BIGTREE_TFT35_V3.0.27.x_portrait.bin
- config.ini
- TFT35 folder
- language_en.ini

A successful update looks like checking your SD card where the names of the items
on the SD card have been changed with the ".CUR" extension.

--------Post Installation--------------
In case major changes have been applied by the installed firmware,
a post installation process consisting on touch screen calibration is automatically started.

The "config.ini" file is a text file that you can modify to refine or set other parameters.
It contains some comments to help you understand. Once defined, you put a copy of this file
on the SD card and proceed to an update.

The hard reset process consists in:
resetting the TFT's configuration to the TFT's default hard coded settings
starting the touch screen calibration process (see Touch Screen Calibration)
at startup before moving to Main menu.

In order to hard reset the firmware:

Copy "reset.txt" file in archive to the root of the SD card.
The SD card capacity should be less than or equal to 8GB and formatted as FAT32
========================================================
More informations, here:
https://github.com/bigtreetech/BIGTREETECH-TouchScreenFirmware

====================== SPECIAL MODS FOR SR AND QQSPro =======================
Tips for the SR MoBo Nanov3:
You can use the original serial cable but you must check the correct wire order and colors because FLSun did not follow the wiring standards:
Red => 5v power supply
Black => Ground
White=>TX data
Green=> RX data
If you want to connect the EXP1/EXP2 ports then you need to flip the connectors 180 degrees.
The best way is to remove the plastic guides and put them back on by turning them 180�.

Tips for the QQSP MoBo HiSpeed:
Only serial connection is possible if you remove the removable wifi module.
For this you have to declare a second SERIAL port in the firmware
"#define SERIAL_PORT_2 1"
and 
"#define NUM_SERIAL 2" 
and make a 4-wire cable using the two pins of the WiFi socket (PA10/PA9 for TX/RX) and
two wires (5V/Ground) for power supply.
A 24v/5v converter is strongly advised.
The correct wire order and colors:
Red => 5v power supply
Black => Ground
White=>TX data (PA9)
Green=> RX data (PA10)

More information on my Wiki in the MODS chapter.
https://github.com/Foxies-CSTL/Marlin_2.1.x/wiki/3.SPECIAL-MODS

Enjoy and have a good printing.